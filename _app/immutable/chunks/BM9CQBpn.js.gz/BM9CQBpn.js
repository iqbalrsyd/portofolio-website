import{h as e}from"./CaskSYCV.js";const s="Resumé",t=e("/pdf/resume.pdf"),o={title:s,resume:t};export{o as R};
