import{j as o}from"./BWBFXw1E.js";function c(l,r){var e;var a=(e=l.$$events)==null?void 0:e[r.type],s=o(a)?a.slice():a==null?[]:[a];for(var t of s)t.call(this,r)}export{c as b};
