const r=(e,n,i="...")=>e.length<=n?e:e.substring(0,n)+i;export{r as e};
