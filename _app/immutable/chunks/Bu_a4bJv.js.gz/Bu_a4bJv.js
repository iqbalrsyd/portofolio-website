import{h as e}from"./BHM51LXH.js";const s="Resumé",t=e("/pdf/resume.pdf"),o={title:s,resume:t};export{o as R};
