import{l as o,a as r}from"../chunks/Cyp29e6S.js";export{o as load_css,r as start};
